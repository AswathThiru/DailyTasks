package com.example.demo;
import com.example.demo.EmailSenderService;
import com.example.demo.model.EmailSender;
import com.example.demo.repository.EmailSenderRepository;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@SpringBootApplication
public class DemoApplication {

	@Autowired
	private EmailSenderRepository emailSenderRepository;

	@Autowired
	private EmailSenderService emailSenderService;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@EventListener(ApplicationReadyEvent.class)
	public void triggerMail() throws MessagingException {
		List<EmailSender> emailSenders = emailSenderRepository.findAll();

		for (EmailSender emailSender : emailSenders) {
			LocalDate startDate = emailSender.getStartDate();
			LocalDate expiryDate = emailSender.getExpiryDate();
			String status = emailSender.getStatus();
			String email = emailSender.getEmail();
			LocalDate todayDate = LocalDate.now();

			if (status.equals("Not Paid") && ChronoUnit.DAYS.between(todayDate, expiryDate) == 30) {
				String[] toEmails = { email };
				emailSenderService.sendSimpleEmail(toEmails, "Testing", "This is a reminder to pay the due.");
			}
		}
	}
}





//@SpringBootApplication
//public class DemoApplication {
//
//	@Autowired
//	private EmailSenderRepository emailSenderRepository;
//
//	@Autowired
//	private EmailSenderService senderService;
//
//	public static void main(String[] args) {
//		SpringApplication.run(DemoApplication.class, args);
//	}
//
//	@EventListener(ApplicationReadyEvent.class)
//	public void triggerMail() throws MessagingException {
//		// Get all email senders from database
//		List<EmailSender> emailSenders = emailSenderRepository.findAll();
//
//		// Iterate over email senders and check if a reminder email should be sent
//		for (EmailSender emailSender : emailSenders) {
//			// Set the values of the start and expiry dates and the status from the database
//			LocalDate startDate = emailSender.getStartDate();
//			LocalDate expiryDate = emailSender.getExpiryDate();
//			String status = emailSender.getStatus();
//			String email = emailSender.getEmail();
//
//			// Check if the status is "Not Paid" and the expiry date is 30 days after the start date
//			if (status.equals("Not Paid") && ChronoUnit.DAYS.between(startDate, expiryDate) == 30) {
//				String[] toEmails = { email };
//				senderService.sendSimpleEmail(toEmails, "Testing", "This is a reminder to pay the due.");
//			}
//		}
//	}
//
//
//}

