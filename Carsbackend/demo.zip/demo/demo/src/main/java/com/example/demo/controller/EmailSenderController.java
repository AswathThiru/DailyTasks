package com.example.demo.controller;


import com.example.demo.EmailSenderService;
import com.example.demo.model.EmailSender;
import com.example.demo.repository.EmailSenderRepository;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EmailSenderController {

    @Autowired
    private EmailSenderRepository emailSenderRepository;

    @Autowired
    private EmailSenderService emailSenderService;

    @PostMapping("/emailSender")
    public EmailSender createEmailSender(@RequestBody EmailSender newEmailSender) throws MessagingException {
        EmailSender savedEmailSender = emailSenderRepository.save(newEmailSender);

        String to = newEmailSender.getEmail();
        String subject = "Welcome to our Organization";
        String body = "Hello " + newEmailSender.getName() + ",\n\nYour default password is 12345";

        emailSenderService.sendSimpleEmail(new String[]{to}, subject, body);

        return savedEmailSender;
    }

    @GetMapping("/emailSenders")
    public List<EmailSender> getAllEmailSenders() {
        return emailSenderRepository.findAll();
    }
}












//@RestController
//public class EmailSenderController {
//    @Autowired
//    private EmailSenderRepository emailSenderRepository;
//    @PostMapping("/emailSender")
//    EmailSender newEmailSender(@RequestBody EmailSender newEmailSender) {
//        return emailSenderRepository.save(newEmailSender);
//    }
//    @GetMapping("/emailSenders")
//    List<EmailSender> getAllEmailSenders() {
//        return emailSenderRepository.findAll();
//    }
//
//
//
//
//}


